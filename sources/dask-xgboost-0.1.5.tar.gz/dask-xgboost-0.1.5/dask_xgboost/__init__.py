from .core import _train, train, predict, XGBClassifier, XGBRegressor  # noqa

__version__ = '0.1.5'
