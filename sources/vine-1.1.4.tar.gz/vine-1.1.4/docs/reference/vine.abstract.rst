=====================================================
 vine.abstract
=====================================================

.. contents::
    :local:
.. currentmodule:: vine.abstract

.. automodule:: vine.abstract
    :members:
    :undoc-members:
