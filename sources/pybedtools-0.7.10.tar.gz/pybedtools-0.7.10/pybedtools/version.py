
# THIS FILE IS GENERATED FROM SETUP.PY
short_version = '0.7.10'
version = '0.7.10'
full_version = '0.7.10'
git_revision = 'e2780135f6241e070281cbdfa799dc3aaff4f020'
release = True

__version__ = version
if not release:
    version = full_version