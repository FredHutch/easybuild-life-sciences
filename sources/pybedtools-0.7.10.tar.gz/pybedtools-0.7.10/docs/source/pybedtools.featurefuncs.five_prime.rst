pybedtools.featurefuncs.five_prime
==================================

.. currentmodule:: pybedtools.featurefuncs

.. autofunction:: five_prime