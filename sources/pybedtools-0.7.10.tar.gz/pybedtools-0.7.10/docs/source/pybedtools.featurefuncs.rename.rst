pybedtools.featurefuncs.rename
==============================

.. currentmodule:: pybedtools.featurefuncs

.. autofunction:: rename