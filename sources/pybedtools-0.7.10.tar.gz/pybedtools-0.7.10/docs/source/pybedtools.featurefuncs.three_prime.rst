pybedtools.featurefuncs.three_prime
===================================

.. currentmodule:: pybedtools.featurefuncs

.. autofunction:: three_prime