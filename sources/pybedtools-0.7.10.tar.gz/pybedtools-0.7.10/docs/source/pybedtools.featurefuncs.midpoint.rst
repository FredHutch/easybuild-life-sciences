pybedtools.featurefuncs.midpoint
================================

.. currentmodule:: pybedtools.featurefuncs

.. autofunction:: midpoint