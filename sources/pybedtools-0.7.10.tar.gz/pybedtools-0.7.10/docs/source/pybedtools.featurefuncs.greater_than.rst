pybedtools.featurefuncs.greater_than
====================================

.. currentmodule:: pybedtools.featurefuncs

.. autofunction:: greater_than