pybedtools.featurefuncs.normalized_to_length
============================================

.. currentmodule:: pybedtools.featurefuncs

.. autofunction:: normalized_to_length