pybedtools.featurefuncs.extend_fields
=====================================

.. currentmodule:: pybedtools.featurefuncs

.. autofunction:: extend_fields