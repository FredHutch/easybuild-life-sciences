pybedtools.featurefuncs.TSS
===========================

.. currentmodule:: pybedtools.featurefuncs

.. autofunction:: TSS