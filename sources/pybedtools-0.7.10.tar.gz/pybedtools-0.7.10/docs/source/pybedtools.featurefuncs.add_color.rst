pybedtools.featurefuncs.add_color
=================================

.. currentmodule:: pybedtools.featurefuncs

.. autofunction:: add_color