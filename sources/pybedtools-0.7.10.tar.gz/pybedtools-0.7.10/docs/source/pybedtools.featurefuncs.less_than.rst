pybedtools.featurefuncs.less_than
=================================

.. currentmodule:: pybedtools.featurefuncs

.. autofunction:: less_than