
.. currentmodule:: pybedtools

.. _Tabix: http://samtools.sourceforge.net/tabix.shtml

.. _download page: http://sourceforge.net/projects/samtools/files/

.. _samtools: http://samtools.sourceforge.net/

.. _tempdir: http://docs.python.org/library/tempfile.html#tempfile.tempdir

.. _filo: https://github.com/arq5x/filo

.. _R: http://www.r-project.org/

.. _BEDTools: http://github.com/arq5x/bedtools

.. _BEDTools documentation: http://code.google.com/p/bedtools/#Documentation

.. _Learn Python the Hard Way: http://learnpythonthehardway.org/static/LearnPythonTheHardWay.pdf

.. _IPython: http://ipython.scipy.org/moin/

.. _BED format: http://genome.ucsc.edu/FAQ/FAQformat#format1

.. _pip: http://www.pip-installer.org/en/latest/installing.html

.. _easy_install: http://pypi.python.org/pypi/setuptools

.. _Python Package Index: http://pypi.python.org/pypi

.. _Cython: http://cython.org/

.. _Python: http://www.python.org/

.. _nosetests: http://somethingaboutorange.com/mrl/projects/nose/

.. _PyYAML: http://pyyaml.org/wiki/PyYAMLDocumentation

.. _Sphinx: http://sphinx.pocoo.org/

.. _Cygwin: http://www.cygwin.com

.. _argparse: http://pypi.python.org/pypi/argparse

.. _nose: http://pypi.python.org/pypi/nose

.. _scipy: http://www.scipy.org/

.. _matplotlib: http://matplotlib.sourceforge.net/
