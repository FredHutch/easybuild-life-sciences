pybedtools.featurefuncs.gff2bed
===============================

.. currentmodule:: pybedtools.featurefuncs

.. autofunction:: gff2bed