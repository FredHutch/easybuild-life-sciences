# flake8: noqa
from __future__ import print_function, division, absolute_import

from warnings import warn

from .delayed import do, value, Delayed, Value, delayed

warn("dask.imperative has been moved to dask.delayed")
