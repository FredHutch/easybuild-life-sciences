"""Interoperate with a `Tensorflow`_ cluster.

.. _Tensorflow: https://www.tensorflow.org/
"""
from dask_tensorflow import start_tensorflow  # noqa
