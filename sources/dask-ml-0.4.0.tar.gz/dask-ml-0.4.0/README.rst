dask-ml
=======

``dask-ml`` is a library for distributed and parallel machine learning using `dask`_.
See the `documentation`_ for more.

.. _dask: http://dask.pydata.org
.. _documentation: http://dask-ml.readthedocs.io/en/latest/index.html
