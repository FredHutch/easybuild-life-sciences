.. _examples:

========
Examples
========

This is a set of runnable Jupyter notebooks.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   examples/hyperparameter-search
   examples/joblib-distributed
   examples/predict
   examples/dask-glm
   examples/xgboost
   examples/tensorflow
   auto_examples/index
