#!C:\Anaconda\python.exe
# EASY-INSTALL-SCRIPT: 'poretools==0.2.0','poretools'
__requires__ = 'poretools==0.2.0'
import pkg_resources
pkg_resources.run_script('poretools==0.2.0', 'poretools')
