import os
import sys
import scripts
from Fast5File import *
from version import __version__
