.. _howtocite:

How to cite
===========

.. include:: ../CITATION.rst
