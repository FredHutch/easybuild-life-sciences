.. include:: README.rst

=================
Table of contents
=================

.. toctree::
   :maxdepth: 2

   installation
   guide
   faq
   develop
   notes
   howtocite
   changes


..
   Indices and tables
   ==================

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
