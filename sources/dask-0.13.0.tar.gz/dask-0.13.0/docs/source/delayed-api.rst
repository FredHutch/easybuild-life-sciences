API
===

.. currentmodule:: dask.delayed

.. autosummary::
   delayed
   compute

.. autofunction:: delayed
.. autofunction:: compute
