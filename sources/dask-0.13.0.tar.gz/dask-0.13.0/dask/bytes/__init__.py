from __future__ import print_function, division, absolute_import

from ..utils import ignoring
from .core import read_bytes, open_files, open_text_files

from . import local

with ignoring(ImportError, SyntaxError):
    from . import s3
