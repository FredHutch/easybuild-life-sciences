joblib.load
===========

.. currentmodule:: joblib

.. autofunction:: load