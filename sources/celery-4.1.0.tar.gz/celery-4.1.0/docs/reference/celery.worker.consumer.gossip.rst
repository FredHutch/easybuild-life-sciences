==================================================
 ``celery.worker.consumer.gossip``
==================================================

.. contents::
    :local:
.. currentmodule:: celery.worker.consumer.gossip

.. automodule:: celery.worker.consumer.gossip
    :members:
    :undoc-members:
