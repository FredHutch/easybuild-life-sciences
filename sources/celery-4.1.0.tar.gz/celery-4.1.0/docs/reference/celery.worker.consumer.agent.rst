==================================================
 ``celery.worker.consumer.agent``
==================================================

.. contents::
    :local:
.. currentmodule:: celery.worker.consumer.agent

.. automodule:: celery.worker.consumer.agent
    :members:
    :undoc-members:
