=====================================
 ``celery.worker.request``
=====================================

.. contents::
    :local:
.. currentmodule:: celery.worker.request

.. automodule:: celery.worker.request
    :members:
    :undoc-members:
