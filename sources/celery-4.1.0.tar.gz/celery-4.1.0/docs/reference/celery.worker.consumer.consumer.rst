==================================================
 ``celery.worker.consumer.consumer``
==================================================

.. contents::
    :local:
.. currentmodule:: celery.worker.consumer.consumer

.. automodule:: celery.worker.consumer.consumer
    :members:
    :undoc-members:
