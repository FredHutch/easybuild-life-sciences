========================================
 ``celery.worker.components``
========================================

.. contents::
    :local:
.. currentmodule:: celery.worker.components

.. automodule:: celery.worker.components
    :members:
    :undoc-members:
