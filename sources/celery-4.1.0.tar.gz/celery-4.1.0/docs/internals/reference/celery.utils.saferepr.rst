===========================================
 ``celery.utils.saferepr``
===========================================

.. contents::
    :local:
.. currentmodule:: celery.utils.saferepr

.. automodule:: celery.utils.saferepr
    :members:
    :undoc-members:
