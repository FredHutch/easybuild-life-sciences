Presentations On Dask
=====================

* PLOTCON 2016, December 2016

  * `Visualizing Distributed Computations with Dask and Bokeh
    <https://www.youtube.com/watch?v=FTJwDeXkggU>`__

* PyData DC, October 2016

  * `Using Dask for Parallel Computing in Python
    <https://www.youtube.com/watch?v=s4ChP7tc3tA>`__

* SciPy 2016, July 2016

  * `Dask Parallel and Distributed Computing
    <https://www.youtube.com/watch?v=PAGjm4BMKlk>`__

* PyData NYC, December 2015

  * `Dask Parallelizing NumPy and Pandas through Task Scheduling
    <https://www.youtube.com/watch?v=mHd8AI8GQhQ>`__

* PyData Seattle, August 2015

  * `Dask: out of core arrays with task scheduling
    <https://www.youtube.com/watch?v=ieW3G7ZzRZ0>`__

* SciPy 2015, July 2015

  * `Dask Out of core NumPy:Pandas through Task Scheduling
    <https://www.youtube.com/watch?v=1kkFZ4P-XHg>`__
