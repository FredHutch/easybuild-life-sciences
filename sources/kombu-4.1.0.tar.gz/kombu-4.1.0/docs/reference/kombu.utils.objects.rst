==========================================================
 Object/Property Utilities - ``kombu.utils.objects``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.utils.objects

.. automodule:: kombu.utils.objects
    :members:
    :undoc-members:
