=============================================
 SLMQ Transport - ``kombu.transport.SLMQ``
=============================================


.. currentmodule:: kombu.transport.SLMQ

.. automodule:: kombu.transport.SLMQ

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:
