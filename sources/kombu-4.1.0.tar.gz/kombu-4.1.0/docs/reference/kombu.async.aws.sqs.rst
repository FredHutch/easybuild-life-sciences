==========================================================
 Async Amazon SQS Client - ``kombu.async.aws.sqs``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.async.aws.sqs

.. automodule:: kombu.async.aws.sqs
    :members:
    :undoc-members:
