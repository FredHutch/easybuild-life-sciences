==========================================================
 Python Compatibility - ``kombu.utils.compat``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.utils.compat

.. automodule:: kombu.utils.compat
    :members:
    :undoc-members:
