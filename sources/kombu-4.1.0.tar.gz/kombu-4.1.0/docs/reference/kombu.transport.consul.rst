================================================
 Consul Transport - ``kombu.transport.consul``
================================================

.. currentmodule:: kombu.transport.consul

.. automodule:: kombu.transport.consul

    .. contents::
        :local:

    Transport
    ---------

    .. autoclass:: Transport
        :members:
        :undoc-members:

    Channel
    -------

    .. autoclass:: Channel
        :members:
        :undoc-members:
