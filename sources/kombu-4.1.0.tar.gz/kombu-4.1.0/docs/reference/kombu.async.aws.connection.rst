==========================================================
 Amazon AWS Connection - ``kombu.async.aws.connection``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.async.aws.connection

.. automodule:: kombu.async.aws.connection
    :members:
    :undoc-members:
