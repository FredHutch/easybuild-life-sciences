==========================================================
 SQS Queues - ``kombu.async.aws.sqs.queue``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.async.aws.sqs.queue

.. automodule:: kombu.async.aws.sqs.queue
    :members:
    :undoc-members:
