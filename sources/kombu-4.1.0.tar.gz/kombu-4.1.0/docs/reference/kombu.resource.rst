==========================================================
 Resource Management - ``kombu.resource``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.resource

.. automodule:: kombu.resource
    :members:
    :undoc-members:
