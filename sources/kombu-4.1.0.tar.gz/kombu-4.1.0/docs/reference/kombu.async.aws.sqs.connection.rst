==========================================================
 SQS Connection - ``kombu.async.aws.sqs.connection``
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.async.aws.sqs.connection

.. automodule:: kombu.async.aws.sqs.connection
    :members:
    :undoc-members:
