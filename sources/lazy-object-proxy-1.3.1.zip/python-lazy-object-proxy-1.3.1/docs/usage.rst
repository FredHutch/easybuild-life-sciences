=====
Usage
=====

To use lazy-object-proxy in a project::

	import lazy_object_proxy
