
.. image:: images/dask_icon.svg
   :alt: Dask logo

.. image:: images/dask_horizontal.svg
   :alt: Dask logo

.. image:: images/dask_horizontal_white.svg
   :alt: Dask logo

.. image:: images/dask_stacked.svg
   :alt: Dask logo

.. image:: images/dask_stacked_white.svg
   :alt: Dask logo
