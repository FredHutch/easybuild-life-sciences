API
===

.. currentmodule:: dask.delayed

.. autosummary::
   delayed

.. autofunction:: delayed
