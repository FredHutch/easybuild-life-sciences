Distributed Scheduling
======================

Dask can run on a cluster of hundreds of machines and thousands of cores.
Technical documentation for the distributed system is located on a separate
website located here:

*   https://distributed.readthedocs.io/en/latest/
