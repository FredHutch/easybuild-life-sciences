import sys


if sys.version_info >= (3, 5):
    from distributed.tests.py3_test_asyncio import *  # flake8: noqa
