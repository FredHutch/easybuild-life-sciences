.. _changelog:

Changelog
=========

.. mdinclude:: ../CHANGELOG.md
